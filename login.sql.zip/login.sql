--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendees`
--

CREATE TABLE `attendees` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `event_id` int(11) NOT NULL,
  `ticket_id` int(255) NOT NULL,
  `Status` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendees`
--

INSERT INTO `attendees` (`id`, `name`, `email`, `phone`, `event_id`, `ticket_id`, `Status`, `created_date`, `modified_date`) VALUES
(162, 'viktor', ' elvis@gmail.com', '09972089188', 23, 172788, 1, '2019-08-06 13:06:00', '2019-08-06 13:06:00'),
(163, 'Kera', 'viktor.vt512@gmail.com', '09972089188', 23, 60465, 0, '2019-08-06 13:11:42', '2019-08-06 13:11:42'),
(168, 'Ye Kyaw Thu', 'yekyawthu@gmail.com', '09692280652', 28, 246636, 5, '2019-08-19 18:02:34', '2019-08-19 18:02:34'),
(169, 'Tun Myint Aung', 'tunmyintaung@gmail.com', '09123456789', 28, 58482, 2, '2019-08-20 00:01:05', '2019-08-20 00:01:05'),
(196, 'Alvin', 'Alvin@gmail.com', '09692280652', 11, 172280, 0, '2019-09-01 20:41:45', '2019-09-01 20:41:45'),
(198, 'Ye Kyaw Thu', 'thuyekyaw6@gmail.com', '09692280652', 11, 162239, 0, '2019-09-01 20:49:28', '2019-09-01 20:49:28'),
(199, 'Alvin', 'Alvin@gmail.com', '09692280652', 30, 106380, 0, '2019-09-01 20:53:42', '2019-09-01 20:53:42'),
(208, 'Ye Kyaw Thu', 'yekyawthu@gmail.com', '09692280652', 11, 177429, 0, '2019-09-01 21:09:48', '2019-09-01 21:09:48'),
(210, 'Alvin', 'elvis@gmail.com', '09692280652', 11, 107802, 2, '2019-09-01 22:34:36', '2019-09-01 22:34:36'),
(213, 'Kera', 'kera@gmail.com', '09692280652', 11, 80388, 0, '2019-09-01 23:04:15', '2019-09-01 23:04:15'),
(214, 'yekyawthu', 'yekyawthu@gmail.com', '09692280652', 30, 126207, 2, '2019-09-02 06:34:20', '2019-09-02 06:34:20'),
(216, 'Alvin', 'Alvin@gmail.com', '09692280652', 31, 37009, 0, '2019-09-02 10:53:18', '2019-09-02 10:53:18'),
(217, 'Kera', 'kera@gmail.com', '09692280652', 28, 240640, 1, '2019-09-02 11:53:50', '2019-09-02 11:53:50'),
(219, 'Alvin', 'Alvin@gmail.com', '09692280652', 34, 44608, 0, '2019-09-05 21:40:10', '2019-09-05 21:40:10'),
(220, 'Ye Kyaw Thu', 'yekyawthu@gmail.com', '09692280652', 34, 149410, 0, '2019-09-06 00:03:18', '2019-09-06 00:03:18'),
(221, 'Ye Kyaw Thu', 'Alvin@gmail.com', '09692280652', 28, 52537, 0, '2019-10-30 08:26:43', '2019-10-30 08:26:43');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `evename` varchar(255) NOT NULL,
  `start_time` date NOT NULL,
  `end_time` date NOT NULL,
  `location` varchar(255) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `attendees` int(11) NOT NULL,
  `abouteve` mediumtext NOT NULL,
  `users_id` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `evename`, `start_time`, `end_time`, `location`, `cover`, `attendees`, `abouteve`, `users_id`, `created_date`, `modified_date`) VALUES
(28, 'Crusaders Of Light (Game Event)', '2019-10-30', '2019-10-31', 'Yangon', '1522943973467.jpg', 0, '		A web browser is a software application for retrieving, presenting and traversing information resources on the World Wide Web. An information resource is defined by a Uniform Resource Identifier (URI) and may be a web page, image, video or other piece of content. Hyperlinks present in resource enables users easily to navigate browsers to related resources. A web browser is defined to enable users to access, retrieve and view documents and other resources on the internet [7].\r\n                Browser is a piece of software that probably use nearly every day. In the beginning Web was introduced as medium for sharing scientific and research documents especially between document organizations and academic institutions. But with the passage of time, it overload crossed the limits defined for it. Initially, till 1990, the World Wide Web remains within the boundaries of CERN (a research organization), but by 1991, it became available to anyone using internet [7].\r\n', 12, '2019-08-19 12:41:54', '2019-09-14 23:11:17'),
(29, 'BITES & VIBES', '2019-11-04', '2019-11-07', 'Amoy St,Singapore', 'bites-and-vibes-foodpanda-1280x720.jpg', 20, '	A web browser is a software application for retrieving, presenting and traversing information resources on the World Wide Web. An information resource is defined by a Uniform Resource Identifier (URI) and may be a web page, image, video or other piece of content. Hyperlinks present in resource enables users easily to navigate browsers to related resources. A web browser is defined to enable users to access, retrieve and view documents and other resources on the internet [7].\r\n       	A web browser is a software application for retrieving, presenting and traversing information resources on the World Wide Web. An information resource is defined by a Uniform Resource Identifier (URI) and may be a web page, image, video or other piece of content. Hyperlinks present in resource enables users easily to navigate browsers to related resources. A web browser is defined to enable users to access, retrieve and view documents and other resources on the internet [7].\r\n        	A web browser is a software application for retrieving, presenting and traversing information resources on the World Wide Web. An information resource is defined by a Uniform Resource Identifier (URI) and may be a web page, image, video or other piece of content. Hyperlinks present in resource enables users easily to navigate browsers to related resources. A web browser is defined to enable users to access, retrieve and view documents and other resources on the internet [7].\r\n               	A web browser is a software application for retrieving, presenting and traversing information resources on the World Wide Web. An information resource is defined by a Uniform Resource Identifier (URI) and may be a web page, image, video or other piece of content. Hyperlinks present in resource enables users easily to navigate browsers to related resources. A web browser is defined to enable users to access, retrieve and view documents and other resources on the internet [7].\r\n ', 12, '2019-08-27 11:10:19', '2019-09-14 23:34:42'),
(30, 'COMEX 2019', '2019-10-31', '2019-11-05', 'Suntec City ,Singapore City', '300-General_COMEX-logo_WhiteBg-300x170.jpg', 10, ' For first time members, MMEN is a platform for fellow entrepreneurs and investors to gather, share ideas on doing business in Myanmar, learn from each other on key areas (e.g HR, Financing, law) or even possibly form partnership! ', 12, '2019-08-27 11:18:15', '2019-09-28 15:15:04'),
(31, ' Startup Skill Bootstrap date', '2019-09-24', '2019-10-01', '628/636 Merchant Road, Between 29th and 30th street Yangon', 'FB_IMG_1567388052639.jpg', 198, '       Startup Skill Bootcamp is one full-day training event for people interested in becoming startup founders in the future. In the morning, you will learn what makes a tech startup and why young technology companies like Facebook and Grab are now more ', 16, '2019-09-02 09:04:15', '2019-09-02 10:32:55'),
(32, 'Myanmar Entreprenures Monthly date', '2019-10-01', '2019-10-03', 'Corner of Kaba Aye Pagoda Road & Kan Yeik Thar Street, Yangon', 'FB_IMG_1567388812117.jpg', 500, ' For MMEN September Networking meetup, Dr. Htet Zan Linn, founder of OnDoctor will be our featured guest.\r\nFounded in July 2016, OnDoctor is a Universal Health Coverage (UHC) focused Health Company.Through leveraging on technology and focusing on the 3 pi', 16, '2019-09-02 09:05:30', '2019-09-02 10:32:30'),
(33, 'Strategic Planning For Professional Business Coaches', '2019-10-24', '2019-10-24', 'Sein Lann So Pyay Garden, Yangon', 'FB_IMG_1567389601087.jpg', 200, 'STRATEGIC PLAINNING For Professional Business Coaches (1) Day Program\r\n\r\nBy: \r\nNai Lo Mung (MBA, UK) \r\nBusiness & Executive Coach\r\nLeadership Development Facilitator \r\nMyanmar 1st Certified NLP Master Trainer', 16, '2019-09-02 10:28:16', '2019-09-02 10:29:09'),
(34, 'Super Sunday Branch', '2019-09-30', '2019-09-30', '192, Kaba Aye Pagoda Road, Bahan Township ,Yangon', 'FB_IMG_1567389943326.jpg', 8, ' Super Sunday BBQ BUFFET from 12.00 - 3.00 PM.\r\n Guess what?? Our DRAFT BEER is only only HALF PRICE !!!! during brunch !!!!!!!\r\n Sukhumvit Branch only.\r\n', 16, '2019-09-02 10:48:10', '2019-09-28 15:25:30');

-- --------------------------------------------------------

--
-- Table structure for table `register_amount`
--

CREATE TABLE `register_amount` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `register_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirm_pwd` varchar(255) NOT NULL,
  `cmp_name` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `type` varchar(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `confirm_pwd`, `cmp_name`, `user_level`, `type`, `created_date`, `modified_date`) VALUES
(10, 'elvis', ' elvis@gmail.com', '09972089188', '12345678', '12345678', 'cmp_name', 2, '', '2019-07-04 09:15:03', '2019-07-04 09:15:03'),
(11, 'viktor', 'viktor.vt512@gmail.com', '09972089188', '12345678', '12345678', 'cmp_name', 1, '', '2019-07-04 10:07:28', '2019-07-04 10:07:28'),
(12, 'casper', 'casper@gmail.com', '09972089188', '12345678', '12345678', 'hello', 2, '', '2019-07-08 13:54:35', '2019-07-08 13:54:35'),
(13, 'Alvin', 'alvin@gmail.com', '09692280652', '12345678', '12345678', 'cmp_name', 2, '', '2019-07-15 21:54:02', '2019-07-15 21:54:02'),
(14, 'Kera', 'kera@gmail.com', '09692280652', '12345678', '12345678', 'cmp_name', 2, '', '2019-07-28 21:19:40', '2019-07-28 21:19:40'),
(16, 'Ye Kyaw Thu', 'thuyekyaw6@gmail.com', '09692280652', '123456', '123456', 'cmp_name', 2, '', '2019-08-02 14:28:22', '2019-08-02 14:28:22'),
(17, 'Khufra', 'Khufra@gmail.com', '09692280652', '123456', '123456', 'cmp_name', 2, '', '2019-08-02 19:31:03', '2019-08-02 19:31:03'),
(23, 'Rose', 'rose@gmail.com', '09972089188', '12345678', '12345678', 'cmp_name', 2, '', '2019-08-06 12:42:47', '2019-08-06 12:42:47');

-- --------------------------------------------------------

--
-- Table structure for table `user_level`
--

CREATE TABLE `user_level` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_level`
--

INSERT INTO `user_level` (`id`, `name`) VALUES
(1, 'Admin'),
(2, 'Member');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendees`
--
ALTER TABLE `attendees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register_amount`
--
ALTER TABLE `register_amount`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_level`
--
ALTER TABLE `user_level`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendees`
--
ALTER TABLE `attendees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;
--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `register_amount`
--
ALTER TABLE `register_amount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `user_level`
--
ALTER TABLE `user_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
